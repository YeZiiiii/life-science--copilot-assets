# Excel Research Figure

**调用名：`excel-research-figure`**

这是对 Nature Figure 科学原则的 Excel Python 专用适配：不依赖本地目录、R、YAML、外部 API、图片样例或其他技能。它不是期刊官方技能，也不保证任何稿件自动符合投稿要求。

## 上传

将整个 `excel-research-figure` 文件夹放入 **Excel → Copilot → Settings → Manage plugins & skills → Custom skills → Open skills folder** 打开的 OneDrive 技能目录，再点 **Refresh**。

文件夹名与 `SKILL.md` 的 name 必须一致。ZIP 是传输容器；如果当前 Excel 界面没有 ZIP 上传入口，先解压再放文件夹，不把 ZIP 当作已确认支持的安装入口。

保留原技能即可；演示时只选择本技能，必要时关闭原 `nature-figure` 的自动使用，避免 Python/R 或本地执行规则混入。

上传目录只有以下 12 个文件：

```text
excel-research-figure
  SKILL.md
  README.md
  LICENSE.md
  NOTICE.md
  references
    excel-python.md
    figure-contract.md
  scripts
    01_data.py
    02_statistics.py
    03_style_audit.py
    04_comparison.py
    05_other_plots.py
    demo_data.py
```

不要把运行产生的 PNG/PDF、工作簿、`__pycache__`、临时文件或验证环境放进技能目录。许可保留为 Markdown，不是无后缀 LICENSE。

## 演示用短提示词

```text
@excel-research-figure
请用 Excel 的 Python 能力运行技能自带的独立组模拟示例，生成“个体点＋均值95%CI”和“相对对照的均值差95%CI”两面板图。明确标注模拟数据，并返回每组原始测量数、独立单位数和处理规则。
```

这一示例有 48 次技术测量，但只有 24 个独立单位，三组各 n=8。模拟演示协议已明确采用“每单位的技术重复取均值”，可直接执行；真实数据中必须先确认，不能自动套用这条规则。

## 真实表格调用

建议 Excel 表 `ExperimentData` 包含：

| 列 | 含义 |
|---|---|
| Condition | 真实组名 |
| UnitID | 独立实验单位 ID；配对时同一单位跨条件相同 |
| Response | 定量测量 |
| TechnicalReplicate | 可选技术重复编号 |

```text
@excel-research-figure
请用当前 ExperimentData 表做科研比较图。Condition 是组别，UnitID 是独立实验单位，Response 的单位是 [实际单位]，设计是 [独立/配对]。技术重复 [不聚合/经确认取均值]，参考组是 [真实组名]。保留数据、标明 n 和区间含义，并返回统计与检查表。
```

## 如何体现“更严谨”

| 普通绘图容易发生的情况 | 技能行为 |
|---|---|
| 将每行当样本，误把技术重复算入 n | 按确认的独立单位处理，显示原始记录数与分析 n |
| 配对记录被当成独立样本 | 核对单位匹配，保留连线并计算配对差值 |
| 只有均值柱，没有分布 | 展示所有分析单位的点和定义清楚的区间 |
| 不清楚误差线是 SD、SEM 还是 CI | 明确计算和标注；不凭空补误差 |
| 靠星号或漂亮配色暗示结论 | 默认不算 p 值/不加星号；展示效应与区间 |
| 数据缺失后静默删行 | 停止并报告，不自动删除或填补 |
| 中文变方框、标签截断、面板错位 | 字形与渲染检查阻断这些问题，保留人工视觉审查 |

## 能力边界

需要账号、版本和租户已启用 Python in Excel，且 Copilot 能读取技能源码并将定义写入 Python 单元格。技能文件不会自动成为云端可 import 的 Python 模块。

编号 `.py` 是按顺序展开到 Python 单元格的辅助函数片段，不是在 Excel 中运行本地文件。它们已经按较保守的单元格长度拆分，不应再拼接成一个超长 `PY()` 公式。图形通过 Matplotlib 对象返回，统计表通过 DataFrame 返回。用户可将图显示在单元格上方；不是原生可编辑图表。

本包没有提供真实研究数据或未经许可的第三方图像。复杂混合效应模型、计数/比例模型、时间序列或多重比较需要另行选择恰当方法，不能把内置均值差区间当万能检验。

详细代码调用、中文字体、官方依据与运行规则见 `references\excel-python.md`。
