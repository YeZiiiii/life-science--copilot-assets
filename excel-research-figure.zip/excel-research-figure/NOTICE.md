# 来源与适配说明

本技能依据用户提供的 `nature-skills` 项目中 `nature-figure` 2.8.0 的图件契约、数据完整性、独立单位、视觉层级及 QA 原则重新编写。

上游项目：https://github.com/yuan1z0825/nature-skills

本次适配将 Python/R 本地工作流改为 Excel Python-only；移除外部 API、本地文件依赖、YAML 路由、跨技能引用及图片/PDF 样例。Python 代码为本次独立实现，并按单元格长度拆分为五个编号片段和一个模拟数据片段；未复制 `figures4papers` 第三方素材或代码。

原项目根目录的 Apache-2.0 许可证原文保留在 `LICENSE.md`。文件扩展名改为 Markdown，仅用于兼容上传文件管理，不改变许可条款。本技能不由原项目作者、Microsoft 或 Nature 期刊官方背书。

Skill 正文、执行规则与脚本均为上述目的而新写/修改的版本，不是未经更改的上游文件。
