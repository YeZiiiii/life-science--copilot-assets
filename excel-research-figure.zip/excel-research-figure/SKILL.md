---
name: excel-research-figure
description: "用 Excel 的 Python 能力创建、改进和审查科研数据图。适用于科研绘图、Nature 风格、组间比较、配对实验、效应量图、散点图和热图。保留原始数据，明确独立实验单位、技术重复、样本量和区间含义；用 Matplotlib 返回真实图形及可核对的统计表，不调用外部生图 API。"
license: Apache-2.0
compatibility: "Copilot in Excel with Python in Excel enabled. Uses xl(), pandas, NumPy, Matplotlib and SciPy from the managed Python environment; no local-file or network access."
metadata:
  version: "1.0.0"
  adapted-from: "nature-figure 2.8.0"
---

# Excel Research Figure

这是基于 Nature Figure 科学契约原则重新编写的 Excel 专用版本，不是原项目的完整移植。Python 是唯一绘图后端，不询问 R，不运行外部 API，不安装包，不读取本地文件，也不依赖其他 Skill 文件夹。

## 目标

让图件的科学逻辑、数据处理和统计含义更严谨，不只是换一个漂亮配色。默认在 Excel 中返回 Matplotlib 图像对象，并提供统计汇总、效应估计与数据/版面检查表。图像不是 Excel 原生图表或可取消组合的矢量图。

不承诺 Nature 投稿合规、不判断临床疗效、不虚构实验值、误差线或显著性。图片生成模型不能替代科研数据绘图。

## 1. 先建立简短图件契约

确认研究问题、数据表/范围、指标及单位、组别顺序、每行含义、独立实验单位 ID、独立/配对设计、技术重复规则、区间定义和输出用途。

已有明确答案就继续，不重复提问。缺少会改变科学结论的信息时，只问必要的一项。尤其不能默认“一行就是一个独立样本”，也不能用“图更好看”决定配对关系或误差线。

默认面向汇报使用 `context="presentation"`；论文尺度使用 `context="paper"` 并检查最终尺寸。核心结论必须由数据支持；缺少结论时用中性的研究问题，不先编出有效/无效。

## 2. 在 Excel 的 Python 中读取数据

只通过 `xl()` 读取实际表格或范围，如 `xl("ExperimentData[#All]", headers=True)`。范围/表名须真实存在，表头明确；合计行和脚注不应被当作观测，识别后请求确认并记录排除。

让 Copilot 按顺序读取并展开以下源码；每个片段放入一个先于调用的 Python 单元格，不拼接为超长公式：

1. [01_data.py](scripts\01_data.py)：导入、对象类型、数据与实验单位检查。
2. [02_statistics.py](scripts\02_statistics.py)：汇总和效应区间。
3. [03_style_audit.py](scripts\03_style_audit.py)：字体、样式与渲染检查。
4. [04_comparison.py](scripts\04_comparison.py)：组间/配对比较图。
5. [05_other_plots.py](scripts\05_other_plots.py)：仅散点或热图需要。

演示时再读取 [demo_data.py](scripts\demo_data.py)。源码读取由宿主工具完成，不是在 Python 中读 OneDrive 文件。

不能 import 这些片段为本地模块，不能使用 `exec(open(...))`、本地路径、HTTP、OpenRouter、API key、shell、pip 或 R。不能用本地脚本跑出图片后声称是 Excel Python 的结果。宿主无法读取脚本资源时，明确报出限制，不伪称已加载。

按 Excel 行优先计算顺序先加载片段再调用，每格不跨半个函数/类。复用已加载定义，避免覆盖用户的现有数据和公式；通过宿主编辑工具使用新输出页或确认的空白区域。Python 变量优先用 `rf_` 前缀。

最后返回 `rf_result.figure`；不要只输出代码建议。Python 不直接写工作表其他单元格，表格结果在后续 Python 单元格返回相应 DataFrame。

## 3. 完整性与实验单位

使用 `prepare_experiment` 检查必需列、空值、非数值、非有限值、组别顺序、单位 ID 和重复。

默认 `technical_replicates="reject"`。同组同单位有多行时，先确认是技术重复还是意外重复；只有用户确认后才能用 `"mean"`，保留每单位原始记录数。图中每点是单位均值，n 是独立单位数，不是技术测量数。

明确请求本包的模拟演示时，演示协议已指定独立组、每单位两次技术测量及取均值，不必重复询问；这个约定不能自动用于真实工作簿。

`design="independent"` 要求单位不跨组重复；`design="paired"` 要求每个单位都有全部指定组。不能静默删除未配对单位、缺失值或离群值。任何获准筛选须另行记录原始/保留数量、规则和理由。

相关采样、不同批次、随机效应或更复杂层级设计不能强塞为独立/完整配对；说明内置方法不覆盖，并按真实设计另写经核对的 Python 分析。

## 4. 用最少必要面板回答问题

内置首选是：

- a：所有分析单位的点＋均值与明确区间，显示 n；配对设计保留单位连线。
- b：只有确认参考组后，展示相对参考组的均值差及 95% 区间；不是重复画同一张柱状图。

调用 `scientific_comparison`。不指定 `reference` 时只做 a，不自动把第一组当对照。不要默认柱状图藏掉分布。

`interval="ci95"` 是均值的双侧 t 型 95% CI；`"sd"` 是均值±样本 SD；`"none"` 只描述均值与观测。区间为逐项区间，不是同时置信区间；没有方差/样本条件就报错，不能用假误差线补齐。

独立组均值差使用 Welch 型区间，配对均值差基于单位差值。区间依赖设计与假设，小样本需特别核对。内置脚本不添加 p 值或星号，不做多重比较校正，不能把探索性点估计当验证性结论。

散点用 `scientific_scatter`，不默认加回归或因果箭头；矩阵用 `scientific_heatmap`，不默认归一化、聚类或补缺失。其他图型可按同样契约在 Excel Python 中编写，不冒称内置脚本已覆盖。

## 5. 科研视觉标准

白底，清晰字体，深色文字；保留指标单位与真实组名，不擅自修改模型名称大小写。对照用中性灰，实验组用节制的色觉友好分类色。颜色还有直接标签/位置辅助，不以红绿作为唯一标识。

比较图显示真实值与区间，不用 3D、彩虹、发光、假装饰网格或未定义的截断坐标。散点保持真实数值刻度；热图色标必须说明单位，顺序色/发散色由数据含义决定。

英文默认无衬线。中文图件可用 Excel 官方的 `excel.FontPath.CHINESE_SIMPLIFIED` 传给 `font_path`；字体不支持字符时明确报错，不交付方框文字。此字体是运行环境支持，不宣称是 Nature 官方字体。

尺寸、字号、颜色与图例说明可调，但不能为了好看删数据、混淆配对或改变科学单位。

## 6. 渲染后检查

脚本自动检查字形、文字越界、刻度标签互相覆盖、指定同尺寸面板的实际轴框对齐，并返回审计表。FAIL 阻断交付；WARN 要人工复核，不得吞掉。

自动检查不是完整视觉审查。还要看整图与面板局部：误差线是否覆盖、字体是否可读、注释是否压数据、色彩是否合适。无法查看实际图时明确列出未验证项。

修改数据、区间、文字或布局后重新运行，不用旧检查表证明新图通过。

## 7. 交付

至少返回实际 Python 图形、图注和 `rf_result.summary`；比较图另外返回 `rf_result.effects`，并提供 `rf_result.data_audit`、`rf_result.layout_audit` 和分析单位映射。

图注说明来源范围、单位、n、配对/独立设计、技术重复、区间含义和处理规则。模拟数据必须在标题/图注明确标注，不与用户真实数据混用。

有缺失能力、Excel Python 不可用、被阻止或资源无法加载时，准确报告；可提供可复制代码，但不能报“已在 Excel 完成”。不默认宣称能从 Excel 云端导出本地 PDF/SVG。

具体用法见 [excel-python.md](references\excel-python.md)，科学边界见 [figure-contract.md](references\figure-contract.md)。上传包只有 Markdown/Python；许可和来源说明保存在 LICENSE.md 与 NOTICE.md。
