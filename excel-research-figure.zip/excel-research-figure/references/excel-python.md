# Excel Python 执行与调用

## 1. 不要从 Python 读取技能文件

Copilot 先通过技能资源读取工具读取 `.py` 源码，再把函数定义展开到 Excel Python 单元格。OneDrive 中的 `.py` 不是 Python 云容器中自动存在的模块。

不要将这些片段 import 为本地模块，不写 `open("C:\\...")`、`pd.read_csv("本地路径")`、`exec(open(...).read())`、外部 HTTP、pip 或 API 调用。Excel Python 不访问本地用户文件或互联网；它不直接创建工作表、修改 Excel 原生图表或 VBA。

辅助代码按文件逐格展开，按工作表行优先计算顺序先定义再调用，不能在一个超长单元格里合并全部源码，也不跨格切断函数/类。前四个编号片段用于比较图，第五个只用于散点/热图，demo_data.py 只用于明确指定的模拟演示。

每个编号片段的保守公式长度估计少于 7,600 个字符、行数少于 220，避开常见公式长度和多行限制。不要通过动态 `exec` 拼接绕过。图最后返回 `rf_result.figure`，不是仅打印 Figure 对象或路径。

## 2. 独立组真实数据

先在不同 Python 单元格按顺序展开 `01_data.py`、`02_statistics.py`、`03_style_audit.py`、`04_comparison.py`，再运行：

```python
rf_source = xl("ExperimentData[#All]", headers=True)
rf_prepared = prepare_experiment(
    rf_source,
    group_col="Condition",
    value_col="Response",
    unit_col="UnitID",
    design="independent",
    technical_replicates="reject",
    order=["Control", "Condition A", "Condition B"],
)
rf_result = scientific_comparison(
    rf_prepared,
    value_label="Response (actual unit)",
    reference="Control",
    interval="ci95",
    title="Experimental response",
)
rf_result.figure
```

组名、表名和单位必须按实际输入修改。group order 不允许悄悄漏组。若用户明确确认技术重复取均值，将 `"reject"` 改为 `"mean"`，不可仅为了让代码跑通而改。

## 3. 演示数据

按顺序展开前四个编号片段及 `demo_data.py`，之后：

```python
rf_demo_source = make_demo_data(seed=7)
rf_prepared = prepare_experiment(
    rf_demo_source,
    group_col="Condition",
    value_col="Response",
    unit_col="UnitID",
    design="independent",
    technical_replicates="mean",
    order=["Control", "Condition A", "Condition B"],
)
rf_result = scientific_comparison(
    rf_prepared,
    value_label="Response (a.u.)",
    title="Three experimental conditions",
    reference="Control",
    interval="ci95",
    demo=True,
)
rf_result.figure
```

源数据是模拟数据，不应替代真实研究输入。无需在 Skill 文件夹保存 CSV 或预生成图片。

如需先把数据展示为表，先在 Python 单元格返回 `rf_demo_source`，确认模拟标记，然后在后续单元格生成图；将数据转为 Excel 值与 spill 由 Excel 输出机制完成，不是 Python 任意写工作表。

## 4. 审计表与图注

在后续 Python 单元格分别返回：

```python
rf_result.summary
```

```python
rf_result.effects
```

```python
rf_result.data_audit
```

```python
rf_result.analysis_units
```

```python
rf_result.layout_audit
```

`analysis_units` 保留每个分析单位的 value 和 raw_measurements；真实敏感 ID 不直接印在图中。图注需写明每点的含义、独立单位 n、配对/独立、技术重复规则、区间定义和输入范围。不能只说“误差线见图”。

## 5. 配对实验

使用 `design="paired"`。同一单位在每个条件都应有记录；缺失条件会报错，不自动 complete-case 删除。

模拟练习可以将 `make_demo_data()` 换为 `make_paired_demo_data()`，技术重复设置 `"reject"`，其余组名相同。图保留配对连线，右面板区间基于单位差值，不是两组独立方差之和。

## 6. 散点与热图

```python
scatter_result = scientific_scatter(
    xy_data, x_col="X", y_col="Y", unit_col="UnitID",
    x_label="X (actual unit)", y_label="Y (actual unit)",
)
scatter_result.figure
```

散点不自动给因果、回归或相关系数；每单位一行。不满足时先处理真实设计。

```python
heatmap_result = scientific_heatmap(
    numeric_matrix, value_label="Measured quantity (actual unit)",
    title="Measured values", center=None,
)
heatmap_result.figure
```

默认顺序色，无归一化/聚类；只有确有正负偏离意义时指定 `center=0` 使用发散色。缺失与无限值直接报错，所有原始单元格都保留。

## 7. 中文和输出

Microsoft 官方提供简体中文字体路径，可传入：

```python
rf_result = scientific_comparison(
    rf_prepared, value_label="响应（实际单位）", title="条件比较",
    reference="Control", font_path=excel.FontPath.CHINESE_SIMPLIFIED,
)
rf_result.figure
```

`excel` 是 Excel Python 环境提供的能力，不在本地安装或通过网络下载。字体不能覆盖某字符时，脚本会报告具体字形问题，不能交付方框。中文字体可能为宋体；字形正确优先于声称某种字体风格。

Matplotlib 图片可通过 Excel 的 **Display Plot over Cells** 显示并调整尺寸。调整显示大小不会提高图形的原始分辨率；也不会把图片变成可逐对象编辑的原生图表。图像导出和论文终稿格式需按实际产品能力另行确认。

## 官方依据

核实日期：2026-10-12。

- Python 绘图、`xl()`、图片对象与中文字体：https://support.microsoft.com/en-us/excel/python/create-plots-and-charts-with-python-in-excel
- Python 云端环境与输入输出限制：https://support.microsoft.com/en-us/excel/python/data-security-and-python-in-excel
- 预置及可导入科学库：https://support.microsoft.com/en-us/excel/python/open-source-libraries-and-python-in-excel
- 自定义技能目录与刷新：https://support.microsoft.com/en-us/excel/copilot/copilot-in-excel-skills
- 公式与单元格限制：https://support.microsoft.com/en-us/excel/excel-specifications-and-limits
- Python 单元格编辑器：https://support.microsoft.com/en-us/excel/python/python-in-excel-code-editor

技能只使用这些已有能力；本地脚本检验不能代替对目标 Excel 账号的实际验证。
