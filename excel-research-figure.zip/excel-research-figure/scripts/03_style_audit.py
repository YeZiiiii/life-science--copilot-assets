# SPDX-License-Identifier: Apache-2.0
"""Excel Python cell fragment 03_style_audit.py; load numbered fragments in order."""

def _style(context, font_path):
    if context not in ("presentation", "paper"):
        raise ValueError("context must be 'presentation' or 'paper'.")
    family = "DejaVu Sans"
    if font_path is not None:
        font_manager.fontManager.addfont(str(font_path))
        family = font_manager.FontProperties(fname=str(font_path)).get_name()
    size = 12 if context == "presentation" else 8
    return {
        "font.family": family, "font.size": size, "axes.labelsize": size,
        "axes.titlesize": size + 1, "figure.titlesize": size + 3,
        "xtick.labelsize": size - 1, "ytick.labelsize": size - 1,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": 0.9, "axes.edgecolor": "#374151",
        "text.color": "#1F2937", "axes.labelcolor": "#1F2937",
        "xtick.color": "#374151", "ytick.color": "#374151",
        "axes.unicode_minus": False, "figure.facecolor": "white",
        "axes.facecolor": "white", "savefig.facecolor": "white",
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }

@lru_cache(maxsize=16)
def _font_characters(filename):
    return frozenset(ft2font.FT2Font(filename).get_charmap())

def _rendered_texts(figure):
    excluded = set()
    for axes in figure.axes:
        for axis in (axes.xaxis, axes.yaxis):
            low, high = sorted(axis.get_view_interval())
            margin = np.finfo(float).eps * max(1, abs(low), abs(high)) * 10
            tick_sets = (
                (axis.get_majorticklocs(), axis.get_major_ticks),
                (axis.get_minorticklocs(), axis.get_minor_ticks),
            )
            for locations, get_ticks in tick_sets:
                for tick, location in zip(get_ticks(len(locations)), locations):
                    if location < low - margin or location > high + margin:
                        excluded.update((id(tick.label1), id(tick.label2)))
    return [text for text in figure.findobj(match=Text)
            if id(text) not in excluded and text.get_visible() and text.get_text().strip()]

def audit_figure(figure, comparable_axes=(), tolerance_pt=1.5):
    """Check text extent, tick-label overlap and declared equal-sized axes."""
    if tolerance_pt <= 0:
        raise ValueError("Alignment tolerance must be positive.")
    records = []
    for text in _rendered_texts(figure):
        label = text.get_text()
        if "$" not in label:
            filename = font_manager.findfont(text.get_fontproperties())
            characters = _font_characters(filename)
            missing = sorted({char for char in label if not char.isspace() and ord(char) not in characters})
            if missing:
                raise FigureValidationError(
                    "Font cannot render " + repr("".join(missing)) +
                    ". For Chinese use font_path=excel.FontPath.CHINESE_SIMPLIFIED.")
    figure.canvas.draw()
    renderer = figure.canvas.get_renderer()
    bounds = figure.bbox
    rendered_texts = _rendered_texts(figure)
    rendered_ids = {id(text) for text in rendered_texts}
    for text in rendered_texts:
        box = text.get_window_extent(renderer)
        if box.x0 < bounds.x0 - 1 or box.y0 < bounds.y0 - 1 or box.x1 > bounds.x1 + 1 or box.y1 > bounds.y1 + 1:
            records.append({"status": "FAIL", "check": "text bounds", "detail": text.get_text()})
    for axis in figure.axes:
        for tick_labels in (axis.get_xticklabels(), axis.get_yticklabels()):
            visible = [text for text in tick_labels if id(text) in rendered_ids]
            boxes = [text.get_window_extent(renderer) for text in visible]
            for left in range(len(boxes)):
                for right in range(left + 1, len(boxes)):
                    if boxes[left].overlaps(boxes[right]):
                        records.append({"status": "FAIL", "check": "tick overlap",
                                        "detail": visible[left].get_text() + " / " + visible[right].get_text()})
    axes = tuple(comparable_axes)
    if len(axes) > 1:
        boxes = [axis.get_window_extent(renderer) for axis in axes]
        scale = 72.0 / figure.dpi
        for attribute in ("y0", "y1", "width", "height"):
            values = [getattr(box, attribute) * scale for box in boxes]
            spread = max(values) - min(values)
            if spread > tolerance_pt:
                records.append({"status": "FAIL", "check": "equal-panel " + attribute,
                                "detail": f"{spread:.3f} pt exceeds {tolerance_pt:.3f} pt"})
    records.append({"status": "PASS" if not records else "FAIL", "check": "automated scope",
                    "detail": "Glyphs, text bounds, tick overlap and declared equal panels only; visual review still required."})
    audit = pd.DataFrame(records, columns=["status", "check", "detail"])
    if audit["status"].eq("FAIL").any():
        raise FigureValidationError(audit.to_string(index=False))
    return audit

def _data_audit(prepared):
    return pd.DataFrame([
        {"item": "input_measurements", "value": prepared.input_rows},
        {"item": "retained_measurements", "value": int(prepared.source_counts["raw_measurements"].sum())},
        {"item": "analysis_rows", "value": len(prepared.units)},
        {"item": "unique_unit_ids", "value": prepared.units["unit"].nunique()},
        {"item": "excluded_measurements", "value": 0},
        {"item": "design", "value": prepared.design},
        {"item": "technical_replicates", "value": prepared.technical_replicates},
        {"item": "inference_scope", "value": "Descriptive/pointwise intervals; assumptions require review."},
    ])

'Definitions ready: 03_style_audit.py'
