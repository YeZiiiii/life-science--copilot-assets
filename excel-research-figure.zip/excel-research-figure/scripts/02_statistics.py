# SPDX-License-Identifier: Apache-2.0
"""Excel Python cell fragment 02_statistics.py; load numbered fragments in order."""

def _mean_interval(values, interval):
    values = np.asarray(values, dtype=float)
    mean = float(values.mean())
    if interval == "none":
        return mean, np.nan, np.nan
    if len(values) < 2:
        raise ValueError("SD/CI requires at least two independent units; use 'none' only for description.")
    sd = float(values.std(ddof=1))
    if interval == "sd":
        return mean, mean - sd, mean + sd
    if sd == 0:
        raise ValueError("Zero sample variance cannot support a meaningful estimated CI; inspect the data.")
    half = float(stats.t.ppf(0.975, len(values) - 1) * sd / np.sqrt(len(values)))
    return mean, mean - half, mean + half

def summarize_experiment(prepared, interval="ci95"):
    _require_prepared(prepared)
    if interval not in ("ci95", "sd", "none"):
        raise ValueError("interval must be 'ci95', 'sd' or 'none'.")
    rows = []
    for group in prepared.order:
        values = prepared.units.loc[prepared.units["group"].eq(group), "value"].to_numpy()
        mean, low, high = _mean_interval(values, interval)
        raw_n = int(prepared.source_counts.loc[
            prepared.source_counts["group"].eq(group), "raw_measurements"].sum())
        rows.append({
            "group": group, "n_units": len(values), "raw_measurements": raw_n,
            "mean": mean, "sd": float(values.std(ddof=1)) if len(values) > 1 else np.nan,
            "interval": interval, "lower": low, "upper": high,
        })
    return pd.DataFrame(rows)

def mean_differences(prepared, reference):
    _require_prepared(prepared)
    if reference not in prepared.order:
        raise ValueError("Reference group is not present; do not infer a control group.")
    if len(prepared.order) < 2:
        raise ValueError("A reference comparison requires at least two groups.")
    source = prepared.units
    baseline = source.loc[source["group"].eq(reference), "value"].to_numpy()
    if len(baseline) < 2:
        raise ValueError("Effect intervals require at least two units in the reference group.")
    rows = []
    for group in prepared.order:
        if group == reference:
            continue
        sample = source.loc[source["group"].eq(group), "value"].to_numpy()
        if len(sample) < 2:
            raise ValueError("Effect intervals require at least two units in every comparison.")
        if prepared.design == "paired":
            paired = source.pivot(index="unit", columns="group", values="value")
            differences = (paired[group] - paired[reference]).to_numpy()
            estimate = float(differences.mean())
            se = float(differences.std(ddof=1) / np.sqrt(len(differences)))
            df = float(len(differences) - 1)
            method = "Paired mean difference; t interval"
        else:
            estimate = float(sample.mean() - baseline.mean())
            var_a = float(sample.var(ddof=1) / len(sample))
            var_b = float(baseline.var(ddof=1) / len(baseline))
            se = float(np.sqrt(var_a + var_b))
            denominator = var_a ** 2 / (len(sample) - 1) + var_b ** 2 / (len(baseline) - 1)
            if denominator == 0:
                raise ValueError("Both groups have zero sample variance; inspect before estimating an effect CI.")
            df = float((var_a + var_b) ** 2 / denominator)
            method = "Independent mean difference; Welch t interval"
        if se == 0 or not np.isfinite(se):
            raise ValueError("A degenerate effect interval was detected; inspect the underlying differences.")
        half = float(stats.t.ppf(0.975, df) * se)
        rows.append({
            "group": group, "reference": reference, "difference": estimate,
            "lower": estimate - half, "upper": estimate + half,
            "n_group": len(sample), "n_reference": len(baseline),
            "degrees_of_freedom": df, "method": method,
            "coverage": "95% pointwise, unadjusted; no p-value",
        })
    return pd.DataFrame(rows)

'Definitions ready: 02_statistics.py'
