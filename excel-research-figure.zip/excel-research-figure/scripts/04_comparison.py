# SPDX-License-Identifier: Apache-2.0
"""Excel Python cell fragment 04_comparison.py; load numbered fragments in order."""

def scientific_comparison(prepared, *, value_label, title="Experimental comparison",
                          reference=None, interval="ci95", context="presentation",
                          font_path=None, demo=False, jitter_seed=7):
    _require_label(value_label, "Value label")
    _require_label(title, "Figure title")
    summary = summarize_experiment(prepared, interval)
    effects = pd.DataFrame() if reference is None else mean_differences(prepared, reference)
    colors = {}
    position = 0
    for group in prepared.order:
        if group == reference:
            colors[group] = "#6B7280"
        else:
            colors[group] = PALETTE[position % len(PALETTE)]
            position += 1
    with mpl.rc_context(_style(context, font_path)):
        figsize = (10, 5.4) if context == "presentation" else (7.09, 3.8)
        figure, axes = plt.subplots(1, 2 if reference is not None else 1,
                                   figsize=figsize, dpi=150, layout="constrained", squeeze=False)
        axis = axes[0, 0]
        rng = np.random.default_rng(jitter_seed)
        if prepared.design == "paired":
            paired = prepared.units.pivot(index="unit", columns="group", values="value").loc[:, prepared.order]
            for _, row in paired.iterrows():
                axis.plot(range(len(prepared.order)), row.to_numpy(), color="#C7CDD4",
                          linewidth=0.8, alpha=0.7, zorder=1)
        for index, row in summary.iterrows():
            values = prepared.units.loc[prepared.units["group"].eq(row["group"]), "value"].to_numpy()
            offsets = np.zeros(len(values)) if prepared.design == "paired" else rng.uniform(-0.13, 0.13, len(values))
            axis.scatter(index + offsets, values, s=30, alpha=0.8,
                         color=colors[row["group"]], edgecolors="white", linewidths=0.4, zorder=2)
            if interval != "none":
                axis.errorbar(index, row["mean"],
                              yerr=[[row["mean"] - row["lower"]], [row["upper"] - row["mean"]]],
                              fmt="D", color="#1F2937", markersize=4.5,
                              capsize=5, elinewidth=1.4, zorder=3)
            else:
                axis.scatter([index], [row["mean"]], marker="D", s=28, color="#1F2937", zorder=3)
        axis.set_xticks(range(len(prepared.order)),
                        [f"{row.group}\nn={row.n_units}" for row in summary.itertuples()])
        axis.set_ylabel(value_label)
        axis.set_xlim(-0.5, len(prepared.order) - 0.5)
        interval_label = {"ci95": "mean + 95% t CI", "sd": "mean +/- SD", "none": "mean only"}[interval]
        axis.set_title("a  Unit-level observations", loc="left")
        axis.margins(y=0.17)
        if reference is not None:
            effect_axis = axes[0, 1]
            effect_axis.axvline(0, color="#9CA3AF", linestyle="--", linewidth=1, zorder=0)
            for index, row in effects.iterrows():
                effect_axis.errorbar(
                    row["difference"], index,
                    xerr=[[row["difference"] - row["lower"]], [row["upper"] - row["difference"]]],
                    fmt="o", color=colors[row["group"]], markersize=6, capsize=4, elinewidth=1.4)
            effect_axis.set_yticks(range(len(effects)),
                                   [f"{row.group} - {row.reference}" for row in effects.itertuples()])
            effect_axis.invert_yaxis()
            effect_axis.set_ylim(len(effects) - 0.5, -0.5)
            effect_axis.set_xlabel("Mean difference in " + value_label)
            effect_axis.set_title("b  Effects relative to reference", loc="left")
            effect_axis.margins(x=0.17)
        prefix = "SYNTHETIC DEMO - " if demo else ""
        repeat_note = "technical repeats averaged per unit" if prepared.technical_replicates == "mean" else "one row per unit"
        figure.suptitle(prefix + title, fontweight="bold" if font_path is None else "normal")
        note = prepared.design + "; " + repeat_note + ". Diamonds: " + interval_label + "; n=units."
        if reference is not None:
            note += "\nEffects: mean difference + 95% CI; pointwise/unadjusted, no p-values."
        figure.supxlabel(note, fontsize=9 if context == "presentation" else 6.5, color="#52616B")
        try:
            audit = audit_figure(figure, comparable_axes=axes[0] if reference is not None else ())
        except FigureValidationError:
            plt.close(figure)
            raise
    mapping = prepared.units.merge(prepared.source_counts, on=["group", "unit"], how="left",
                                   validate="one_to_one")
    return FigureResult(figure, summary, effects, _data_audit(prepared), audit, mapping)

'Definitions ready: 04_comparison.py'
