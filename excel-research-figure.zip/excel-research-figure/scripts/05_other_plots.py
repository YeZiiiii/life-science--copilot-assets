# SPDX-License-Identifier: Apache-2.0
"""Excel Python cell fragment 05_other_plots.py; load numbered fragments in order."""

def scientific_scatter(frame, *, x_col, y_col, unit_col, x_label, y_label,
                       title="Observed relationship", context="presentation",
                       font_path=None, demo=False):
    _require_label(x_label, "X label")
    _require_label(y_label, "Y label")
    _require_label(title, "Figure title")
    _require_frame(frame, [x_col, y_col, unit_col])
    identifiers = _labels(frame[unit_col], "Unit")
    if identifiers.duplicated().any():
        raise ValueError("Repeated unit IDs require an explicit repeated-measure plotting design.")
    x = _numeric(frame[x_col])
    y = _numeric(frame[y_col])
    with mpl.rc_context(_style(context, font_path)):
        figure, axis = plt.subplots(figsize=(7.5, 5), dpi=150, layout="constrained")
        axis.scatter(x, y, s=38, color=PALETTE[0], alpha=0.8, edgecolors="white", linewidths=0.4)
        axis.set_xlabel(x_label)
        axis.set_ylabel(y_label)
        axis.set_title(("SYNTHETIC DEMO - " if demo else "") + title + f"; n={len(frame)}")
        axis.margins(0.12)
        try:
            audit = audit_figure(figure)
        except FigureValidationError:
            plt.close(figure)
            raise
    summary = pd.DataFrame([{"n_units": len(frame), "x_mean": x.mean(), "y_mean": y.mean(),
                             "regression": "not fitted", "causality": "not inferred"}])
    source = pd.DataFrame({"unit": identifiers.to_numpy(), "x": x.to_numpy(), "y": y.to_numpy()})
    return FigureResult(figure, summary, pd.DataFrame(),
                        pd.DataFrame([{"item": "excluded_measurements", "value": 0}]), audit, source)

def scientific_heatmap(matrix, *, value_label, title="Measurement matrix",
                       center=None, context="presentation", font_path=None, demo=False):
    _require_label(value_label, "Colorbar label")
    _require_label(title, "Figure title")
    if not isinstance(matrix, pd.DataFrame) or matrix.empty:
        raise ValueError("Heatmap input must be a nonempty numeric DataFrame.")
    if not matrix.index.is_unique or not matrix.columns.is_unique:
        raise ValueError("Heatmap row and column identifiers must be unique.")
    values = np.column_stack([_numeric(matrix[column]).to_numpy() for column in matrix.columns])
    if float(np.ptp(values)) == 0:
        raise ValueError("All heatmap values are identical; a color gradient would not show a real difference.")
    if center is not None and not np.isfinite(center):
        raise ValueError("Heatmap center must be finite.")
    with mpl.rc_context(_style(context, font_path)):
        figure, axis = plt.subplots(figsize=(7.5, 5), dpi=150, layout="constrained")
        if center is None:
            image = axis.imshow(values, cmap="viridis", aspect="auto", interpolation="nearest")
        else:
            radius = float(np.max(np.abs(values - center)))
            image = axis.imshow(values, cmap="RdBu_r", vmin=center - radius, vmax=center + radius,
                                aspect="auto", interpolation="nearest")
        axis.set_xticks(range(len(matrix.columns)), [str(label) for label in matrix.columns],
                        rotation=45, ha="right")
        axis.set_yticks(range(len(matrix.index)), [str(label) for label in matrix.index])
        axis.set_title(("SYNTHETIC DEMO - " if demo else "") + title)
        colorbar = figure.colorbar(image, ax=axis, shrink=0.85)
        colorbar.set_label(value_label)
        try:
            audit = audit_figure(figure)
        except FigureValidationError:
            plt.close(figure)
            raise
    summary = pd.DataFrame([{"rows": len(matrix.index), "columns": len(matrix.columns),
                             "minimum": values.min(), "maximum": values.max(),
                             "normalization": "none", "clustering": "none"}])
    return FigureResult(figure, summary, pd.DataFrame(),
                        pd.DataFrame([{"item": "excluded_cells", "value": 0}]), audit, matrix.copy())

'Definitions ready: 05_other_plots.py'
