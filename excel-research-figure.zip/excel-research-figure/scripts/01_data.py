# SPDX-License-Identifier: Apache-2.0
"""Excel Python cell fragment 01_data.py; load numbered fragments in order."""

from dataclasses import dataclass

from functools import lru_cache

from typing import Optional, Tuple

import numpy as np

import pandas as pd

import matplotlib as mpl

import matplotlib.pyplot as plt

from matplotlib import font_manager, ft2font

from matplotlib.figure import Figure

from matplotlib.text import Text

from scipy import stats

PALETTE = ("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9")

class FigureValidationError(ValueError):
    pass

@dataclass
class PreparedExperiment:
    units: pd.DataFrame
    source_counts: pd.DataFrame
    order: Tuple[str, ...]
    design: str
    technical_replicates: str
    input_rows: int

@dataclass
class FigureResult:
    figure: Figure
    summary: pd.DataFrame
    effects: pd.DataFrame
    data_audit: pd.DataFrame
    layout_audit: pd.DataFrame
    analysis_units: pd.DataFrame

def _require_label(label, role):
    if not isinstance(label, str) or not label.strip():
        raise ValueError(role + " must be nonempty text; provide the quantity and unit.")

def _require_frame(frame, columns):
    if not isinstance(frame, pd.DataFrame):
        raise ValueError("Input must be a pandas DataFrame returned by xl().")
    if frame.empty:
        raise ValueError("No observations were provided.")
    if not frame.columns.is_unique:
        raise ValueError("Column names must be unique.")
    if len(set(columns)) != len(columns):
        raise ValueError("Group, value and unit columns must be different.")
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise ValueError("Required columns are missing: " + ", ".join(map(str, missing)))
    if frame[columns].isna().any().any():
        raise ValueError("Required fields contain missing values; no rows were dropped.")

def _numeric(series):
    if series.map(lambda value: isinstance(value, (bool, np.bool_))).any():
        raise ValueError("Boolean values are not quantitative measurements.")
    try:
        converted = pd.to_numeric(series, errors="raise").astype(float)
    except (TypeError, ValueError) as error:
        raise ValueError("Measurement values must be numeric; no rows were dropped.") from error
    if not np.isfinite(converted.to_numpy()).all():
        raise ValueError("Measurements contain NaN or infinity; no rows were dropped.")
    return converted

def _labels(series, role):
    labels = series.map(str)
    if labels.str.strip().eq("").any():
        raise ValueError(role + " contains blank identifiers.")
    if series.nunique(dropna=False) != labels.nunique(dropna=False):
        raise ValueError(role + " has identifiers that collide when displayed as text.")
    return labels

def prepare_experiment(frame, *, group_col, value_col, unit_col, design,
                       technical_replicates="reject", order=None):
    """Preserve every row, or explicitly average technical repeats per unit."""
    _require_frame(frame, [group_col, value_col, unit_col])
    if design not in ("independent", "paired"):
        raise ValueError("Specify design='independent' or design='paired'.")
    if technical_replicates not in ("reject", "mean"):
        raise ValueError("technical_replicates must be 'reject' or explicitly 'mean'.")
    data = pd.DataFrame({
        "group": _labels(frame[group_col], "Group").to_numpy(),
        "unit": _labels(frame[unit_col], "Unit").to_numpy(),
        "value": _numeric(frame[value_col]).to_numpy(),
    })
    available = tuple(pd.unique(data["group"]))
    selected = available if order is None else tuple(map(str, order))
    if len(set(selected)) != len(selected) or set(selected) != set(available):
        raise ValueError("Group order must contain every observed group exactly once.")
    counts = data.groupby(["group", "unit"], sort=False, observed=True).size()
    if counts.gt(1).any() and technical_replicates == "reject":
        raise ValueError("Repeated group/unit rows found. Confirm technical repeats before using 'mean'.")
    units = data.groupby(["group", "unit"], sort=False, observed=True,
                         as_index=False)["value"].mean()
    counts = counts.rename("raw_measurements").reset_index()
    memberships = units.groupby("unit", sort=False, observed=True)["group"].nunique()
    if design == "independent" and memberships.gt(1).any():
        raise ValueError("Unit IDs cross groups. Confirm paired design or use truly unique unit IDs.")
    if design == "paired":
        if len(selected) < 2:
            raise ValueError("Paired design requires at least two groups.")
        if memberships.ne(len(selected)).any():
            raise ValueError("Incomplete pairs found. No unmatched units were silently removed.")
    return PreparedExperiment(units, counts, selected, design,
                              technical_replicates, len(data))

def _require_prepared(prepared):
    if not isinstance(prepared, PreparedExperiment):
        raise ValueError("Call prepare_experiment before summarizing or plotting.")
    _require_frame(prepared.units, ["group", "unit", "value"])
    _numeric(prepared.units["value"])
    if prepared.units.duplicated(["group", "unit"]).any():
        raise ValueError("Prepared units were altered: each group/unit must have one analysis value.")
    if set(prepared.units["group"]) != set(prepared.order):
        raise ValueError("Prepared group order no longer matches its data.")
    if prepared.design not in ("independent", "paired"):
        raise ValueError("Prepared design is invalid.")
    memberships = prepared.units.groupby("unit", observed=True)["group"].nunique()
    if prepared.design == "independent" and memberships.gt(1).any():
        raise ValueError("Prepared independent-unit membership was altered.")
    if prepared.design == "paired" and memberships.ne(len(prepared.order)).any():
        raise ValueError("Prepared paired data are incomplete.")
    _require_frame(prepared.source_counts, ["group", "unit", "raw_measurements"])
    if prepared.source_counts.duplicated(["group", "unit"]).any():
        raise ValueError("Prepared source counts have duplicate keys.")
    unit_keys = set(map(tuple, prepared.units[["group", "unit"]].to_numpy()))
    count_keys = set(map(tuple, prepared.source_counts[["group", "unit"]].to_numpy()))
    if unit_keys != count_keys:
        raise ValueError("Prepared data and source-count mapping no longer match.")
    counts = _numeric(prepared.source_counts["raw_measurements"])
    if (counts < 1).any() or not np.equal(counts, np.floor(counts)).all():
        raise ValueError("Raw measurement counts must be positive integers.")
    if counts.sum() != prepared.input_rows:
        raise ValueError("Prepared raw measurement counts no longer match the input count.")

'Definitions ready: 01_data.py'
