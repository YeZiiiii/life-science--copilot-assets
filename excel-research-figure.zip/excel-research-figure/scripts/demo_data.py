# SPDX-License-Identifier: Apache-2.0
"""Explicitly synthetic teaching data; never substitute for user measurements."""

import numpy as np
import pandas as pd


def make_demo_data(seed=7):
    """Three conditions, eight independent units each, two technical readings."""
    rng = np.random.default_rng(seed)
    rows = []
    for condition, mean in [("Control", 10.0), ("Condition A", 11.3), ("Condition B", 12.8)]:
        for number in range(1, 9):
            response = float(rng.normal(mean, 1.4))
            for replicate in (1, 2):
                rows.append({
                    "Condition": condition,
                    "UnitID": condition.replace(" ", "_") + "_" + str(number),
                    "TechnicalReplicate": replicate,
                    "Response": response + float(rng.normal(0, 0.25)),
                    "DataOrigin": "SYNTHETIC_DEMO_NOT_RESEARCH",
                })
    return pd.DataFrame(rows)


def make_paired_demo_data(seed=11):
    """Same eight units observed under three conditions; all records are simulated."""
    rng = np.random.default_rng(seed)
    baselines = rng.normal(10, 2.5, size=8)
    rows = []
    for number, baseline in enumerate(baselines, start=1):
        for condition, shift in [("Control", 0.0), ("Condition A", 0.8), ("Condition B", 1.5)]:
            rows.append({
                "Condition": condition, "UnitID": "Subject_" + str(number),
                "Response": float(baseline + shift + rng.normal(0, 0.45)),
                "DataOrigin": "SYNTHETIC_DEMO_NOT_RESEARCH",
            })
    return pd.DataFrame(rows)
