# 医学视觉参考与跨学科研究结构

核实日期：2026-10-12。参考图的视觉与原文图注进行了交叉核对；v2.0.1 增加 R5 作为计算机主演示。这里只保存原创分析、通用设计转化和链接，不打包论文、截图或第三方 icon。

“代表性”指对本任务有明确方法图价值，不是以期刊名称证明设计最优或声称已核查实时引用排名。视觉上以用户参考图为主，其他论文用于扩展实验及临床结构。

## R1. 用户参考图：AI 支持的抗纤维化药物研究

Ren et al. **A small-molecule TNIK inhibitor targets fibrosis in preclinical and clinical models**. Nature Biotechnology, 2024.

DOI：https://doi.org/10.1038/s41587-024-02143-0

全文与 Fig. 1：https://pmc.ncbi.nlm.nih.gov/articles/PMC11738990/

核对范围：正文的靶点发现与生成化学相关段落、Fig. 1 图注、完整 Fig. 1 图像；用户参考为 Fig. 1a。

可迁移：带图标实底输入卡；白底彩边复合方法面板；绿/蓝两个主色域；无衬线正文；短方法 bullet；局部宽渐变箭头；内部并列与跨列模块；候选收敛和末端分级评估。

不可泛化：TNIK、siRNA、五候选/一个靶点、化学生成、体外与动物实验是该研究内容，不是其他论文的默认流程。Fig. 1a 只覆盖该研究的一部分总体流程，不能把它当所有临床部分的完整描述。

权限提示：PMC 文章页面说明 CC BY 4.0，并保留第三方内容例外。直接使用或改编原图仍需核实图的署名/第三方说明、归属与许可证要求。本包不复制原图；只是提炼通用设计语法。

## R2. 实验方法：CITE-seq

Stoeckius et al. **Simultaneous epitope and transcriptome measurement in single cells**. Nature Methods, 2017.

DOI：https://doi.org/10.1038/nmeth.4380

全文与 Fig. 1：https://pmc.ncbi.nlm.nih.gov/articles/PMC5669064/

核对范围：方法介绍、Fig. 1 图注与图像，重点 Fig. 1b 的实验流程。

图中流程将抗体标记、洗涤、微流控封装、细胞裂解和捕获关系以操作/对象示意组织，而不是只写阶段名称。多个相关局部画面展示了从整体实验到关键局部的层级。

可迁移：将真实操作与材料结合；画清楚上游处理如何生成下一步输入；需要时用一个局部放大示意说明关键步骤；保留配对测量/共同条码等科学区别。

不迁移：原图里的具体微流控结构、序列、数据面板、物种颜色或全部生物素材；不能因此给其他论文补 CITE-seq。原图既有示意又有真实数据，生成时不能把数据面板当装饰重画。

权限提示：PMC 为作者稿，未据此确认全部图像均可自由复制。公开可看不等于可再分发。本包不包含图像。

## R3. 临床影像：OCT 诊断与转诊方法

De Fauw et al. **Clinically applicable deep learning for diagnosis and referral in retinal disease**. Nature Medicine, 2018.

DOI：https://doi.org/10.1038/s41591-018-0107-6

作者公开说明与 Fig. 1：

https://defauw.ai/clinically-applicable-deep-learning-retinal-disease

核对范围：作者公开的方法说明和 Figure 1 图像；出版社图页直接读取返回 406，未把作者网页说成已读完整论文。

主路径为 OCT 输入 → 分割 → 组织表征 → 分类 → 诊断/转诊输出，训练分割资料与诊断标注资料在上方分别进入相应阶段。

可迁移：把训练/标注输入与应用主路径分开；标明中间表征；输出可以是概率或建议而不是笼统“成功”；把不同类型关系分开安排。

不迁移：原始 OCT、病灶、概率数字、实际曲线或 3D 组织图形。原图的 3D 和多种组织色用于具体医学内容，并非新版 icon 默认风格。

权限提示：作者网页公开图像，不等于已确认可复制或改编许可证。本包不包含图像，只引用链接与方法结构。

## R4. 多模态分析：WNN / Seurat v4

Hao et al. **Integrated analysis of multimodal single-cell data**. Cell, 2021.

DOI：https://doi.org/10.1016/j.cell.2021.04.048

全文与 Fig. 1：https://pmc.ncbi.nlm.nih.gov/articles/PMC8238499/

核对范围：WNN 方法相关段落、Fig. 1 图注与图像。

图中 RNA 与蛋白分析作为并行模态，经邻居预测/权重判断连接到联合分析。Fig. 1 包含真实数据图，不是与用户参考相同的 icon-rich 实验流程图。

本参考仅补充结构原则：保留模态名称，区分独立处理与融合；不能把并行流程排成先后，不用合并文字抹掉细胞特异权重等核心科学信息。

不用于复制它的散点、热图或其布局，也不把 WNN 当所有组学实验的必需步骤。

权限提示：PMC 页面说明文章 CC BY 4.0，仍需核查图的第三方内容例外。本包不含图像。

## R5. 计算机主演示：GitHub Copilot 的单任务对照实验

Peng, Kalliamvakou, Cihon and Demirer. **The Impact of AI on Developer Productivity: Evidence from GitHub Copilot**. arXiv, 2023.

来源：https://arxiv.org/abs/2302.06590

本次核对的 v1 PDF：https://arxiv.org/pdf/2302.06590v1

核对范围：公开 PDF 的研究设计、结果、讨论及全部 8 个图题。全文 19 页，正文到第 8 页；后面主要为参考文献及附录。已有图为招募/合同/邮件/任务截图、样本描述和结果，没有整体研究方法 Pipeline；不能称为“完全无图”论文，也不称为 CHI 论文或已经确认同行评审的版本。

骨架：95 名专业开发者 → 随机分为 Copilot 组 45 人、对照组 50 人 → 同一 JavaScript HTTP 服务器任务 → GitHub Classroom 记录、12 项功能测试与时间戳 → 完成率/完成时间分析及退出问卷。

可迁移：随机分组形成并行支路；同一任务与同一功能检查支持可比较测量；客观指标与主观问卷区分。不把随机分配人数等同于完成者人数；5 名处理组参与者未完成 Copilot 注册需在备注说明。

该研究对象是 GitHub Copilot，不是 Microsoft 365 或 PowerPoint Copilot；单任务用时变化不能外推为所有研发效率。功能测试通过也不是整体代码质量评估。R5 只用于选文和研究结构，医学参考图仍是视觉来源。

## 从这些参考提炼的共同规则

| 规则 | 主要依据 |
|---|---|
| Pipeline 由对象、操作、读出和连接组成 | R1、R2、R3 |
| 主要方法域内可以有真实子结构 | R1、R2 |
| 颜色主要组织工作域/对象，不自动表示数量 | R1 的视觉；本技能设计转化 |
| 图标/实验示意与操作标签共同解释方法 | R1、R2 |
| 并行模态与汇合需忠实保留 | R4 |
| 训练、标注输入与推理主路径分开 | R3 |
| 评估/验证层级要与原文匹配 | 各参考的具体研究结构；可靠性要求 |
| 渐变、白 icon、双主色与字号 | R1 启发后定制，不是所有参考共有或期刊强制 |

## 科学设计与产品边界

Nature 原始研究图指南：

https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/

投影、受众和图注的通用建议：

https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1003833

颜色之外的冗余编码：

https://jfly.uni-koeln.de/color/

文字/非文字对比度设计目标：

https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html

https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html

上述是设计参考，不宣称这份 PPT 达到投稿或无障碍认证。参考图中有渐变/少量明暗效果，并不证明 Nature 原始研究投稿指南推荐所有图都使用这些效果。

Microsoft 个人 PowerPoint Skill：

https://support.microsoft.com/en-us/powerpoint/copilot/copilot-in-powerpoint-skills

Agent Skills 格式：

https://agentskills.io/specification

文件创建及不同入口：

https://support.microsoft.com/en-us/powerpoint/copilot/create-a-new-presentation-with-copilot-in-powerpoint

https://support.microsoft.com/en-us/powerpoint/frequently-asked-questions-about-copilot-in-powerpoint

这些官方资料在本轮之前已直接核实：个人技能使用独立目录、SKILL.md、name/description，可通过技能菜单或 @ 调用；部分工作账号文件创建入口支持 PDF，另一 Agent Mode 说明文件引用仍在推出。演示仍须实测所用模式，不推断所有入口已有同样能力。

本包不提供组织发布 manifest 或已部署 agent，不附图片/PDF，不把原生渐变或 SVG 转换当所有宿主都有的功能。
